#ifndef Calibration_h
#define Calibration_h

void CalibrateREF(void);
void CalibrateDCB1(void);
void CalibrateDCB2(void);
void CalibrateVrf(void);
void CalibrateVrf2Drive(void);

#endif
